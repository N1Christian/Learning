const express = require('express');
const http = require('http');
const path = require('path');

const httpServerIP = 'localhost';
const httpPort = 8084;
const SSE_URL = `http://${httpServerIP}:${httpPort}/subscribe`;
const appHttp = express();

appHttp.listen(httpPort, () => {
    console.log("listen on port 8084")
})

//sappHttp.use('/public', express.static(path.join(__dirname, 'public')));

appHttp.get('/map_app_demo', (req, res) => {

    res.sendFile(path.join(__dirname,'phrase4_product.html'));
});

appHttp.get('/use.png', (req, res) => {

    res.sendFile(path.join(__dirname,'use.png'));
});